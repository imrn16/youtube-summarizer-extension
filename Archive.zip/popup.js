// Popup script for YouTube Video Summarizer
document.addEventListener("DOMContentLoaded", function () {
	// Simple popup that just shows the extension is ready
	console.log("YouTube Video Summarizer extension is ready!");
});
